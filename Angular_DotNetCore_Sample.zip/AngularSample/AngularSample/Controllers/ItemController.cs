﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace AngularSample.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ItemController : ControllerBase
    {
        private readonly AngularSampleContext _context;

        public ItemController(AngularSampleContext context)
        {
            _context = context;
        }

        /// <summary>
        /// get data from items and categories
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IEnumerable<CetgoryItemViewModel> Get()
        {
            var items = _context.CategoryItem.ToList();
            var grp = (from t in items
                       group t by new { t.CategoryId, t.CategoryName } into g
                       select new CetgoryItemViewModel
                       {
                           Id = g.Key.CategoryId,
                           Name = g.Key.CategoryName,
                           Items = g.ToList()
                       }).OrderBy(m => m.Name);
            return grp;
        }

        /// <summary>
        /// Add new Item
        /// </summary>
        /// <param name="model">contains items fields</param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Save([FromBody]CategoryItem model)
        {
            _context.CategoryItem.Add(model);
            await _context.SaveChangesAsync();
            return Ok(new
            {
                id = model.Id
            });
        }

        /// <summary>
        /// delete item
        /// </summary>
        /// <param name="id">item primary key</param>
        /// <returns></returns>
        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            var item = await _context.CategoryItem.SingleOrDefaultAsync(m => m.Id == id);
            if (item == null)
            {
                return NotFound();
            }

            _context.CategoryItem.Remove(item);
            await _context.SaveChangesAsync();

            return Ok(item);
        }
    }

}

