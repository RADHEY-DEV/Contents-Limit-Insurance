import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { getBaseUrl } from '../../main';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent {
  public categories: Categories[];

  // init reactive form
  itemForm = new FormGroup({
    name: new FormControl(''),
    cost: new FormControl(''),
    categoryId: new FormControl(1),
  });

  constructor(private http: HttpClient) {
    // get data on initial load
    this.getCategories();
  }

  // get items from api
  public getCategories() {
    this.http.get<Categories[]>(getBaseUrl() + 'item').subscribe(result => {
      this.categories = result;
    }, error => console.error(error));
  }

  //add new item
  public addItem() {
    const formValues = this.itemForm.value;
    this.http.post(getBaseUrl() + 'item', formValues).subscribe(data => {
      this.getCategories();
      this.itemForm.patchValue({
        name: '',
        cost: '',
      });
    }, error => console.error(error));
  }

  //delete item
  public deleteItem(item) {
    if (confirm('Do you want to delet this item?')) {
      this.http.delete(getBaseUrl() + 'item?id=' + item.id).subscribe(data => {
        this.getCategories();
      }, error => console.error(error));
    }
  }

  sum = function (items, prop) {
    return items.reduce(function (a, b) {
      return a + b[prop];
    }, 0);
  };

  public itemCost(items) {
    return this.sum(items, 'cost');
  }

  public totalSum() {
    let sum = 0;

    if (this.categories && this.categories.length > 0) {
      for (let i = 0; i < this.categories.length; i++) {
        sum += this.sum(this.categories[i].items, 'cost');
      }
    }

    return sum;
  }

}
