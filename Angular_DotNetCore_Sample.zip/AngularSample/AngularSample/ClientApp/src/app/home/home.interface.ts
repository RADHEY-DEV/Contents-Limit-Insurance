interface Categories {
  id: number;
  name: string;
  items: Items[];
  itemCost: string;
}

interface Items {
  name: string;
  cost: number;
}
