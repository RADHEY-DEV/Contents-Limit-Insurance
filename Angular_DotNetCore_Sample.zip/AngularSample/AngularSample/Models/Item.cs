using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AngularSample
{
    public class CetgoryItemViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<CategoryItem> Items { get; set; }
    }

    public class CategoryItem
    {
        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        [Column(TypeName = "decimal(18,4)")]
        public decimal Cost { get; set; }

        public int CategoryId { get; set; }

        [NotMapped]
        public string CategoryName
        {
            get
            {
                switch (CategoryId)
                {
                    case 1:
                        return "Electronics";
                    case 2:
                        return "Furniture";
                    case 3:
                        return "Immovable";
                    case 4:
                        return "Other";
                    default:
                        return "";

                }
            }
        }
    }
}
