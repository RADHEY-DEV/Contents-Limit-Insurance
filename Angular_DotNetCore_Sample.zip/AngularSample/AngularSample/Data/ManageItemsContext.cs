using Microsoft.EntityFrameworkCore;
using System;

namespace AngularSample
{
    public class AngularSampleContext : DbContext
    {
        public AngularSampleContext(DbContextOptions<AngularSampleContext> options)
            : base(options)
        {
        }

        public DbSet<CategoryItem> CategoryItem { get; set; }
    }
}
